
module Calculator {
	requires java.desktop;
}