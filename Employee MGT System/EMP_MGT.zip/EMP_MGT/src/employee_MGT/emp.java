package employee_MGT;

import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.border.LineBorder;


public class emp {
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame("EMP Home");

        frame.setSize(1200, 800);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Set light background color to JFrame
        frame.getContentPane().setBackground(new Color(240, 240, 240));  // light gray

        JLabel label = new JLabel("Employee Management System");
        label.setBounds(390, 100, 600, 50); // Adjusted position and width
        label.setFont(new Font("Times New Roman", Font.BOLD, 30));
        label.setForeground(new Color(50, 50, 50)); 
        frame.add(label);
        
        
        // Button 1 - New Registration
        JButton btn_New = new JButton("New Registration");
        btn_New.setBounds(320, 310, 180, 50);
        btn_New.setBackground(new Color(100, 180, 255));  // Light blue
        btn_New.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_New.setForeground(Color.WHITE);
        btn_New.setFocusPainted(false);
        frame.add(btn_New);
        
        
        // Action for New Registration
           btn_New.addActionListener(new ActionListener() {
               public void actionPerformed(ActionEvent e) {
                   frame.dispose(); // Close current window
                   newReg nr = new newReg(); // Assuming newReg extends JFrame
                  nr.setVisible(true);
               }
           });

        // Button 2 - View Records
        JButton btn_View = new JButton("View Records");
        btn_View.setBounds(690, 310, 180, 50);
        btn_View.setBackground(new Color(100, 180, 255));  
        btn_View.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_View.setForeground(Color.WHITE);
        btn_View.setFocusPainted(false);
        frame.add(btn_View);
        
     // Action for View Records
        btn_View.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close current window
                ViewEMp view = new ViewEMp(); // Assuming ViewEMp extends JFrame
                view.setVisible(true);
            }
        });
      
        
        
        JButton btn_update = new JButton("Update Data");
        btn_update.setBounds(320, 450, 180, 50);
        btn_update.setBackground(new Color(100, 180, 255));  
        btn_update.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_update.setForeground(Color.WHITE);
        btn_update.setFocusPainted(false);
        frame.add(btn_update);
        
        btn_update.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close current window
                update view = new update(); // Assuming ViewEMp extends JFrame
                view.setVisible(true);
            }
        });
        
        
        JButton btn_delete = new JButton("Delete Data");
        btn_delete.setBounds(690, 450, 180, 50);
        btn_delete.setBackground(new Color(100, 180, 255));  
        btn_delete.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_delete.setForeground(Color.WHITE);
        btn_delete.setFocusPainted(false);
        frame.add(btn_delete);
        
        
        btn_delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close current window
                delete view = new delete(); // Assuming ViewEMp extends JFrame
                view.setVisible(true);
            }
        });
        
        
        JButton btn_exit = new JButton("Exit");
        btn_exit.setBounds(1000, 650, 80, 40);
        btn_exit.setBackground(new Color(100, 180, 255));  
        btn_exit.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_exit.setForeground(Color.WHITE);
        btn_exit.setFocusPainted(false);
        frame.add(btn_exit);
        frame.setVisible(true);
        
        
    }
}

