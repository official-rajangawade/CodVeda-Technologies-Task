package employee_MGT;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.util.ArrayList;
import java.io.FileWriter;



public class ViewEMp extends JFrame {

    public ViewEMp() {
        setTitle("View Employee");
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel label = new JLabel("View Employee Data");
        label.setFont(new Font("Times New Roman", Font.BOLD, 30));
        label.setBounds(490, 100, 400, 40);
        add(label);

        // ✅ Column names
        String[] columnNames = {"E_ID", "Name", "Adhar Card", "Mobile", "Address", "Salary"};

        // ✅ Prepare data from employeeList
        String[][] data = new String[newReg.employeeList.size()][8];
        for (int i = 0; i < newReg.employeeList.size(); i++) {
            DB emp = newReg.employeeList.get(i);  // Use Employee class
            data[i][0] = emp.getE_id();
            data[i][1] = emp.getName();
            data[i][2] = emp.getAdhar();
           // data[i][3] = emp.getDob();
            data[i][3] = emp.getMobile();
            data[i][4] = emp.getAddress();
            //data[i][6] = emp.getDoj();
            data[i][5] = emp.getSalary();
        }

        // ✅ Create JTable
        JTable table = new JTable(data, columnNames);
        table.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        table.setRowHeight(30);
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Times New Roman", Font.BOLD, 18));
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        // Apply the center renderer to all columns
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

       

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 200, 1000, 350);
        add(scrollPane);
        
        
        
        
        

        // ✅ Update Button
        JButton btn_update = new JButton("Update");
        btn_update.setBounds(100, 600, 100, 40);
        btn_update.setBackground(new Color(100, 180, 255));
        btn_update.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_update.setForeground(Color.WHITE);
        btn_update.setFocusPainted(false);
        add(btn_update);

        btn_update.addActionListener(e -> {
            dispose();
            update view = new update(); // assuming this class exists
            view.setVisible(true);
        });

        
        JButton btn_delete = new JButton("Delete");
        btn_delete.setBounds(400, 600, 100, 40);
        btn_delete.setBackground(new Color(100, 180, 255));
        btn_delete.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_delete.setForeground(Color.WHITE);
        btn_delete.setFocusPainted(false);
        add(btn_delete);
        
        btn_delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close current window
                delete view = new delete(); // Assuming ViewEMp extends JFrame
                view.setVisible(true);
            }
        });
        
        JButton btn_download = new JButton("Download");
        btn_download.setBounds(695, 600, 120, 40);
        btn_download.setBackground(new Color(100, 180, 255));
        btn_download.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_download.setForeground(Color.WHITE);
        btn_download.setFocusPainted(false);
        add(btn_download);
        
        
        btn_download.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Save as Text File");
                    int userSelection = fileChooser.showSaveDialog(null);
                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                        if (!filePath.toLowerCase().endsWith(".txt")) {
                            filePath += ".txt";
                        }

                        // Write employee data to TXT
                        FileWriter writer = new FileWriter(filePath);
                        writer.write("----------- Employee Data -----------\n\n");

                        for (DB emp : newReg.employeeList) {
                            writer.write("E_ID     : " + emp.getE_id() + "\n");
                            writer.write("Name     : " + emp.getName() + "\n");
                            writer.write("Adhar    : " + emp.getAdhar() + "\n");
                            writer.write("Mobile   : " + emp.getMobile() + "\n");
                            writer.write("Address  : " + emp.getAddress() + "\n");
                            writer.write("Salary   : " + emp.getSalary() + "\n");
                            writer.write("-------------------------------------\n\n");
                        }

                        writer.flush();
                        writer.close();

                        JOptionPane.showMessageDialog(null, "Data downloaded successfully as TXT!");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error while downloading TXT.");
                }
            }
        });


        
        
        
        // ✅ Back Button
        JButton btn_Back = new JButton("Back");
        btn_Back.setBounds(1010, 600, 80, 40);
        btn_Back.setBackground(new Color(100, 180, 255));
        btn_Back.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_Back.setForeground(Color.WHITE);
        btn_Back.setFocusPainted(false);
        add(btn_Back);

        btn_Back.addActionListener(e -> {
            dispose();
            emp.main(null); // assuming this is your main screen
        });

        setVisible(true); // finally show the frame
    }
}
