package employee_MGT;


import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class update extends JFrame{
	
	public static java.util.ArrayList<DB> employeeList = new java.util.ArrayList<>();

	public update() {
        setTitle("Update Employee");
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        
        JLabel label = new JLabel("Update Employee Data");
        label.setFont(new Font("Times New Roman", Font.BOLD, 30));
        label.setBounds(450, 100, 400, 40);
        add(label);
	
        JLabel label1 = new JLabel("E_ID : ");
        label1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label1.setBounds(220, 230, 100, 50);
        add(label1);
        
        JLabel label2 = new JLabel("Adhar Card : ");
        label2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label2.setBounds(220, 335, 150, 50);
        add(label2);
        
        JLabel label3 = new JLabel("Mobile No : ");
        label3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label3.setBounds(220, 440, 110, 50);
        add(label3);
        
        JLabel label4 = new JLabel("Name : ");
        label4.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label4.setBounds(670, 230, 100, 50);
        add(label4);
        
//        JLabel label5 = new JLabel("DOB : ");
//        label5.setFont(new Font("Times New Roman", Font.PLAIN, 20));
//        label5.setBounds(600, 280, 100, 50);
//        add(label5);
        
        JLabel label6 = new JLabel("Address : ");
        label6.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label6.setBounds(670, 335, 100, 50);
        add(label6);
        
//        JLabel label7 = new JLabel("Date of Joining: ");
//        label7.setFont(new Font("Times New Roman", Font.PLAIN, 20));
//        label7.setBounds(150, 440, 150, 50);
//        add(label7);
        
        JLabel label8 = new JLabel("Salary : ");
        label8.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label8.setBounds(670, 440, 150, 50);
        add(label8);
        
        
        JTextField jtext = new JTextField();		// E_ID
        jtext.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext.setBounds(330, 230, 150, 40);
        add(jtext);
        
        JTextField jtext1 = new JTextField();		// NAme
        jtext1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext1.setBounds(750, 230, 200, 40);
        add(jtext1);

        JTextField jtext2 = new JTextField();		// Adhar
        jtext2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext2.setBounds(330, 335, 200, 40);
        add(jtext2);
        
//        JTextField jtext3 = new JTextField();
//        jtext3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
//        jtext3.setBounds(680, 280, 200, 40);
//        add(jtext3);
        
        JTextField jtext4 = new JTextField();	//Mobile
        jtext4.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext4.setBounds(330, 440, 200, 40);
        add(jtext4);
        
        JTextField jtext5 = new JTextField(); 	//Address
        jtext5.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext5.setBounds(750, 335, 200, 40);
        add(jtext5);
        
//        JTextField jtext6 = new JTextField();
//        jtext6.setFont(new Font("Times New Roman", Font.PLAIN, 20));
//        jtext6.setBounds(285, 440, 200, 40);
//        add(jtext6);
       
        JTextField jtext7 = new JTextField(); 	//Salary
        jtext7.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext7.setBounds(750, 440, 200, 40);
        add(jtext7);


    
    JButton btn_Search = new JButton("Search");
    btn_Search.setBounds(490, 230, 90, 35);
    btn_Search.setBackground(new Color(100, 180, 255));  
    btn_Search.setFont(new Font("Times New Roman", Font.PLAIN, 18));
    btn_Search.setForeground(Color.WHITE);
    btn_Search.setFocusPainted(false);
    add(btn_Search);
    
    
 // 🔍 Search Button Logic
    btn_Search.addActionListener(e -> {
        String enteredId = jtext.getText().trim();
        
        boolean found = false;

        for (DB emp : newReg.employeeList) {
            if (emp.getE_id().equals(enteredId)) {
                // Populate the fields
                jtext1.setText(emp.getName());
                jtext2.setText(emp.getAdhar());
               // jtext3.setText(emp.getDob());
                jtext4.setText(emp.getMobile());
                jtext5.setText(emp.getAddress());
               // jtext6.setText(emp.getDoj());
                jtext7.setText(emp.getSalary());
                found = true;
                break;
            }
        }

        if (!found) {
        	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Employee with ID " + enteredId + " not found.");
        }
    });

    
    
    JButton btn_Update = new JButton("Update");
    btn_Update.setBounds(500, 600, 100, 40);
    btn_Update.setBackground(new Color(100, 180, 255));
    btn_Update.setFont(new Font("Times New Roman", Font.PLAIN, 18));
    btn_Update.setForeground(Color.WHITE);
    btn_Update.setFocusPainted(false);
    add(btn_Update);

    btn_Update.addActionListener(e -> {
        String e_id = jtext.getText().trim();
        String name = jtext1.getText().trim();
        String adhar = jtext2.getText().trim();
      //  String dob = jtext3.getText().trim(); // Assuming optional validation
        String mobile = jtext4.getText().trim();
        String address = jtext5.getText().trim();
       // String doj = jtext6.getText().trim(); // Assuming optional validation
        String salary = jtext7.getText().trim();

        // 🔍 Validations
        if (!e_id.matches("\\d+")) {
            UIManager.put("OptionPane.buttonFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "E_ID must contain only numbers.");
            return;
        }
        if (!name.matches("[a-zA-Z ]+")) {
        	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Name must contain only alphabets.");
            return;
        }
        if (!adhar.matches("\\d{12}")) {
        	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Adhar Card must be exactly 12 digits.");
            return;
        }
        if (!mobile.matches("\\d{10}")) {
        	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Mobile number must be exactly 10 digits.");
            return;
        }
        if (!address.matches("[a-zA-Z0-9 ,.-]+")) {
        	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Address must contain valid characters (letters/numbers/spaces).");
            return;
        }
        if (!salary.matches("\\d+(\\.\\d+)?")) {
        	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Salary must be a valid number.");
            return;
        }

        // ✅ Passed all validation — create and add employee
//        
        boolean updated = false;

        for (DB emp : newReg.employeeList) {
            if (emp.getE_id().equals(e_id)) {
                emp.setName(name);
                emp.setAdhar(adhar);
                emp.setMobile(mobile);
                emp.setAddress(address);
                emp.setSalary(salary);
                updated = true;
                break;
            }
        }

        if (updated) {

        	UIManager.put("OptionPane.buttonFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Employee updated successfully!");
        } else {
        	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Employee ID not found. Update failed.");
        }

       // employeeList.add(emp);

       // JOptionPane.showMessageDialog(null, "Employee updated successfully!");

        // Clear fields
        jtext.setText("");
        jtext1.setText("");
        jtext2.setText("");
       // jtext3.setText("");
        jtext4.setText("");
        jtext5.setText("");
       // jtext6.setText("");
        jtext7.setText("");

        // Debug output
        for (DB e1 : employeeList) {
            System.out.println(e1);
        }
    });


    
    // Add your form components here

    JButton btn_Back = new JButton("Back");
    btn_Back.setBounds(900, 600, 80, 40);
    btn_Back.setBackground(new Color(100, 180, 255));  
    btn_Back.setFont(new Font("Times New Roman", Font.PLAIN, 18));
    btn_Back.setForeground(Color.WHITE);
    btn_Back.setFocusPainted(false);
    add(btn_Back);
    
    
    // Add your form components here
    btn_Back.addActionListener(e -> {
        dispose(); // close current frame
        emp.main(null); // reopen the main home window
    });

    setVisible(true); // make sure it's visible
}


}

