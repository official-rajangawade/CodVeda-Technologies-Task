package employee_MGT;


public class DB {
    private String e_id;
    private String name;
    private String adhar;
  //  private String dob;
    private String mobile;
    private String address;
  //  private String doj;
    private String salary;
    
    
    
    public String getE_id() { return e_id; }
    public String getName() { return name; }
    public String getAdhar() { return adhar; }
   // public String getDob() { return dob; }
    public String getMobile() { return mobile; }
    public String getAddress() { return address; }
  //  public String getDoj() { return doj; }
    public String getSalary() { return salary; }
    
    //public String getE_id() { return e_id; }
    public void setName(String name) { this.name = name; }
    public void setAdhar(String adhar) { this.adhar = adhar; }
    //public void setDob(String dob) { this.dob = dob; }
    public void setMobile(String mobile) { this.mobile = mobile; }
    public void setAddress(String address) { this.address = address; }
   // public void setDoj(String doj) { this.doj = doj; }
    public void setSalary(String salary) { this.salary = salary; }
    // Similarly, add remaining setters if not present



    public DB(String e_id, String name, String adhar, String mobile, String address, String salary) {
        this.e_id = e_id;
        this.name = name;
        this.adhar = adhar;
        //this.dob = dob;
        this.mobile = mobile;
        this.address = address;
       // this.doj = doj;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "e_id='" + e_id + '\'' +
                ", name='" + name + '\'' +
                ", adhar='" + adhar + '\'' +
                //", dob='" + dob + '\'' +
                ", mobile='" + mobile + '\'' +
                ", address='" + address + '\'' +
              //  ", doj='" + doj + '\'' +
                ", salary='" + salary + '\'' +
                '}';
    }
}

