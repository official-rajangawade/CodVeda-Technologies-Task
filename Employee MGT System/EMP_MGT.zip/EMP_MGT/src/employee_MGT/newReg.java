package employee_MGT;

import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.border.LineBorder;


public class newReg extends JFrame {
	public static java.util.ArrayList<DB> employeeList = new java.util.ArrayList<>();
	
	public newReg() {
        setTitle("New Employee Registration");
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Example label (you can add your registration fields here)
        JLabel label = new JLabel("New Employee Registration Form");
        label.setFont(new Font("Times New Roman", Font.BOLD, 30));
        label.setBounds(400, 100, 450, 40);
        add(label);
        
        
        JLabel label1 = new JLabel("E_ID : ");
        label1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label1.setBounds(220, 230, 100, 50);
        add(label1);
        
        JLabel label2 = new JLabel("Adhar Card : ");
        label2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label2.setBounds(220, 335, 150, 50);
        add(label2);
        
        JLabel label3 = new JLabel("Mobile No : ");
        label3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label3.setBounds(220, 440, 110, 50);
        add(label3);
        
        JLabel label4 = new JLabel("Name : ");
        label4.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label4.setBounds(670, 230, 100, 50);
        add(label4);
        
//        JLabel label5 = new JLabel("DOB : ");
//        label5.setFont(new Font("Times New Roman", Font.PLAIN, 20));
//        label5.setBounds(600, 280, 100, 50);
//        add(label5);
        
        JLabel label6 = new JLabel("Address : ");
        label6.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label6.setBounds(670, 335, 100, 50);
        add(label6);
        
//        JLabel label7 = new JLabel("Date of Joining: ");
//        label7.setFont(new Font("Times New Roman", Font.PLAIN, 20));
//        label7.setBounds(150, 440, 150, 50);
//        add(label7);
        
        JLabel label8 = new JLabel("Salary : ");
        label8.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        label8.setBounds(670, 440, 150, 50);
        add(label8);
        
        
        JTextField jtext = new JTextField();		// E_ID
        jtext.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext.setBounds(330, 230, 150, 40);
        add(jtext);
        
        JTextField jtext1 = new JTextField();		// NAme
        jtext1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext1.setBounds(750, 230, 200, 40);
        add(jtext1);

        JTextField jtext2 = new JTextField();		// Adhar
        jtext2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext2.setBounds(330, 335, 200, 40);
        add(jtext2);
        
//        JTextField jtext3 = new JTextField();
//        jtext3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
//        jtext3.setBounds(680, 280, 200, 40);
//        add(jtext3);
        
        JTextField jtext4 = new JTextField();	//Mobile
        jtext4.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext4.setBounds(330, 440, 200, 40);
        add(jtext4);
        
        JTextField jtext5 = new JTextField(); 	//Address
        jtext5.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext5.setBounds(750, 335, 200, 40);
        add(jtext5);
        
//        JTextField jtext6 = new JTextField();
//        jtext6.setFont(new Font("Times New Roman", Font.PLAIN, 20));
//        jtext6.setBounds(285, 440, 200, 40);
//        add(jtext6);
       
        JTextField jtext7 = new JTextField(); 	//Salary
        jtext7.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        jtext7.setBounds(750, 440, 200, 40);
        add(jtext7);
        
        
        
        JButton btn_Back = new JButton("Back");
        btn_Back.setBounds(900, 600, 80, 40);
        btn_Back.setBackground(new Color(100, 180, 255));  
        btn_Back.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_Back.setForeground(Color.WHITE);
        btn_Back.setFocusPainted(false);
        add(btn_Back);
        
        
        JButton btn_Submit = new JButton("Submit");
        btn_Submit.setBounds(500, 600, 100, 50);
        btn_Submit.setBackground(new Color(100, 180, 255));  
        btn_Submit.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        btn_Submit.setForeground(Color.WHITE);
        btn_Submit.setFocusPainted(false);
        add(btn_Submit);
        
        btn_Submit.addActionListener(e -> {
            String e_id = jtext.getText().trim();
            String name = jtext1.getText().trim();
            String adhar = jtext2.getText().trim();
           // String dob = jtext3.getText().trim();
            String mobile = jtext4.getText().trim();
            String address = jtext5.getText().trim();
          //  String doj = jtext6.getText().trim();
            String salary = jtext7.getText().trim();

            // 🔍 Field validations
            if (!e_id.matches("\\d+")) {
            	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
                JOptionPane.showMessageDialog(null, "E_ID must contain only numbers.");
                return;
            }
            if (!name.matches("[a-zA-Z ]+")) {
            	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
                JOptionPane.showMessageDialog(null, "Name must contain only alphabets.");
                return;
            }
            if (!adhar.matches("\\d{12}")) {
            	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
                JOptionPane.showMessageDialog(null, "Adhar Card must be exactly 12 digits.");
                return;
            }
            if (!mobile.matches("\\d{10}")) {
            	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
                JOptionPane.showMessageDialog(null, "Mobile number must be exactly 10 digits.");
                return;
            }
            if (!address.matches("[a-zA-Z0-9 ,.-]+")) {
            	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
                JOptionPane.showMessageDialog(null, "Address must contain valid characters.");
                return;
            }
            if (!salary.matches("\\d+(\\.\\d+)?")) {
            	UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
                JOptionPane.showMessageDialog(null, "Salary must be a valid number.");
                return;
            }
//            if (!isValidDate(dob)) {
//                JOptionPane.showMessageDialog(null, "DOB must be in dd/MM/yyyy format.");
//                return;
//            }
//            if (!isValidDate(doj)) {
//                JOptionPane.showMessageDialog(null, "Date of Joining must be in dd/MM/yyyy format.");
//                return;
//            }

            // ✅ Passed all checks
            DB emp = new DB(e_id, name, adhar, mobile, address, salary);
            employeeList.add(emp);
            UIManager.put("OptionPane.messageFont", new Font("Times New Roman", Font.PLAIN, 16));
            JOptionPane.showMessageDialog(null, "Employee added successfully!");

            // Clear fields
            jtext.setText(""); jtext1.setText(""); jtext2.setText("");
            jtext4.setText(""); jtext5.setText(""); jtext7.setText("");
        });

        
        // Add your form components here

        btn_Back.addActionListener(e -> {
            dispose(); // close current frame
            emp.main(null); // reopen the main home window
        });
        
        setVisible(true); // make sure it's visible

	}
	public static boolean isValidDate(String dateStr) {
	    try {
	        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
	        sdf.setLenient(false);
	        sdf.parse(dateStr); // will throw ParseException if invalid
	        return true;
	    } catch (Exception e) {
	        return false;
	    }
	}

}