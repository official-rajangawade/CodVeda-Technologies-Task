/**
 * 
 */
/**
 * 
 */
module EMP_MGT {
	requires java.desktop;
	requires jdk.internal.md;
	//requires itext;
}