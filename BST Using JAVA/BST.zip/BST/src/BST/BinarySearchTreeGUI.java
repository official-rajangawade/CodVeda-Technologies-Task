package BST;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Node class
class TreeNode {
    int data;
    TreeNode left, right;

    TreeNode(int item) {
        data = item;
        left = right = null;
    }
}

// Binary Search Tree Logic
class BinarySearchTree {
    TreeNode root;

    public TreeNode insert(TreeNode root, int data) {
        if (root == null) {
            return new TreeNode(data);
        }
        if (data < root.data) root.left = insert(root.left, data);
        else if (data > root.data) root.right = insert(root.right, data);
        return root;
    }

    public TreeNode delete(TreeNode root, int key) {
        if (root == null) return null;
        if (key < root.data) root.left = delete(root.left, key);
        else if (key > root.data) root.right = delete(root.right, key);
        else {
            if (root.left == null) return root.right;
            else if (root.right == null) return root.left;
            root.data = minValue(root.right);
            root.right = delete(root.right, root.data);
        }
        return root;
    }

    int minValue(TreeNode root) {
        int min = root.data;
        while (root.left != null) {
            root = root.left;
            min = root.data;
        }
        return min;
    }

    public boolean search(TreeNode root, int key) {
        if (root == null) return false;
        if (key == root.data) return true;
        if (key < root.data) return search(root.left, key);
        return search(root.right, key);
    }

    public void inorder(TreeNode root, StringBuilder sb) {
        if (root != null) {
            inorder(root.left, sb);
            sb.append(root.data).append(" ");
            inorder(root.right, sb);
        }
    }

    public void preorder(TreeNode root, StringBuilder sb) {
        if (root != null) {
            sb.append(root.data).append(" ");
            preorder(root.left, sb);
            preorder(root.right, sb);
        }
    }

    public void postorder(TreeNode root, StringBuilder sb) {
        if (root != null) {
            postorder(root.left, sb);
            postorder(root.right, sb);
            sb.append(root.data).append(" ");
        }
    }
}

// GUI Class
public class BinarySearchTreeGUI extends JFrame {
    private JTextField inputField;
    private JTextArea outputArea;
    private BinarySearchTree bst;

    public BinarySearchTreeGUI() {
        bst = new BinarySearchTree();
        setTitle("Binary Search Tree GUI");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        Font font = new Font("Times New Roman", Font.PLAIN, 19);

        JLabel label = new JLabel("Enter value:");
        label.setBounds(90, 30, 150, 35);
        label.setFont(font);
        add(label);

        inputField = new JTextField();
        inputField.setBounds(215, 30, 120, 35);
        inputField.setFont(font);
        add(inputField);

        JButton insertBtn = new JButton("Insert");
        insertBtn.setBounds(400, 30, 120, 35);
        insertBtn.setFont(font);
        insertBtn.addActionListener(e -> insertNode());
        add(insertBtn);

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(590, 30, 120, 35);
        deleteBtn.setFont(font);
        deleteBtn.addActionListener(e -> deleteNode());
        add(deleteBtn);

        JButton searchBtn = new JButton("Search");
        searchBtn.setBounds(780, 30, 120, 35);
        searchBtn.setFont(font);
        searchBtn.addActionListener(e -> searchNode());
        add(searchBtn);

        JButton inorderBtn = new JButton("In-order");
        inorderBtn.setBounds(215, 90, 120, 35);
        inorderBtn.setFont(font);
        inorderBtn.addActionListener(e -> showTraversal("inorder"));
        add(inorderBtn);

        JButton preorderBtn = new JButton("Pre-order");
        preorderBtn.setBounds(400, 90, 120, 35);
        preorderBtn.setFont(font);
        preorderBtn.addActionListener(e -> showTraversal("preorder"));
        add(preorderBtn);

        JButton postorderBtn = new JButton("Post-order");
        postorderBtn.setBounds(590, 90, 120, 35);
        postorderBtn.setFont(font);
        postorderBtn.addActionListener(e -> showTraversal("postorder"));
        add(postorderBtn);

        outputArea = new JTextArea();
        outputArea.setFont(font);
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);

        JScrollPane scroll = new JScrollPane(outputArea);
        scroll.setBounds(50, 150, 895, 460);
        add(scroll);    }

    private void insertNode() {
        try {
            int val = Integer.parseInt(inputField.getText());
            bst.root = bst.insert(bst.root, val);
            outputArea.setText("Inserted: " + val);
            inputField.setText("");
        } catch (NumberFormatException e) {
            outputArea.setText("Please enter a valid number.");
        }
    }

    private void deleteNode() {
        try {
            int val = Integer.parseInt(inputField.getText());
            bst.root = bst.delete(bst.root, val);
            outputArea.setText("Deleted: " + val);
            inputField.setText("");
        } catch (NumberFormatException e) {
            outputArea.setText("Please enter a valid number.");
        }
    }

    private void searchNode() {
        try {
            int val = Integer.parseInt(inputField.getText());
            boolean found = bst.search(bst.root, val);
            outputArea.setText(found ? "Found: " + val : "Not Found: " + val);
            inputField.setText("");
        } catch (NumberFormatException e) {
            outputArea.setText("Please enter a valid number.");
        }
    }

    private void showTraversal(String type) {
        StringBuilder sb = new StringBuilder();
        switch (type) {
            case "inorder" -> {
                sb.append("In-order Traversal:\n");
                bst.inorder(bst.root, sb);
            }
            case "preorder" -> {
                sb.append("Pre-order Traversal:\n");
                bst.preorder(bst.root, sb);
            }
            case "postorder" -> {
                sb.append("Post-order Traversal:\n");
                bst.postorder(bst.root, sb);
            }
        }
        outputArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BinarySearchTreeGUI gui = new BinarySearchTreeGUI();
            gui.setVisible(true);
        });
    }
}

